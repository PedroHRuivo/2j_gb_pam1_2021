import { LiteralMapEntry } from '@angular/compiler/src/output/output_ast';
import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  imagens = [

   'adulto.jpg',
   'crianca.jpg',
   'idoso.jpg',
   'jovens.jpeg',
   'morte.jpg',
   'tempo.jpg',

 ];
 imagem = this.imagens[0];
 idade = null;
 nome = null;


  constructor() {}

verificar(): void{

  if(this.idade > 0 && this.idade <= 10 ){
    this.imagem = this.imagens[1];
  }else if(this.idade >= 11 && this.idade<=25){
    this.imagem = this.imagens[3];
  }else if(this.idade >= 26 && this.idade<=59){
    this.imagem = this.imagens[0];
  } else if(this.idade > 59 && this.idade<=110){
    this.imagem = this.imagens[2];
  } else if(this.idade > 110){
    this.imagem = this.imagens[4];
  }



}
Limpar(): void{
  this.imagem = this.imagens[0];
this.idade = null;
this.nome = null;
}

}
